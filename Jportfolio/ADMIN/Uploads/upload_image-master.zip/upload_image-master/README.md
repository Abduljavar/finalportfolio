# Upload, update, delete image with PHP &amp; MySQL


## Load SQL File
Load `test-02-07-2018.sql`
Database: `test`
Table: `images`

_Edit `class/Database.php` according to your setup_
