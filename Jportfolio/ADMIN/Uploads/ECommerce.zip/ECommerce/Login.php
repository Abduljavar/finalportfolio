<?php
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if username and password are set
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Your authentication logic (e.g., checking against a database)
        // For demonstration, I'm just using hardcoded values
        $valid_username = 'user';
        $valid_password = 'password';

        if ($username === $valid_username && $password === $valid_password) {
            // Authentication successful
            // Set session variables and redirect to a protected page
            $_SESSION['username'] = $username;
            header("Location: index.html");
            exit;
        } else {
            // Authentication failed
            echo "Invalid username or password.";
        }
    } else {
        echo "Please enter both username and password.";
    }
}
?>
